package com.suschunkfinder.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.suschunkfinder.config.ModConfig;
import com.suschunkfinder.module.PlayerDebugModule;
import com.suschunkfinder.module.StorageEspModule;
import com.suschunkfinder.module.SusChunkModule;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * World overlay renderer for Sus Chunk / Player Debug / Storage ESP.
 * Wrapped in try-catch so rendering errors never crash the client.
 */
public class ModRenderer {

    public static void render(WorldRenderContext context) {
        try {
            renderInner(context);
        } catch (Throwable t) {
            // Never crash the game because of overlay rendering
        }
    }

    private static void renderInner(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;

        // Camera position - works with both old and new render context
        Vec3d cam = client.gameRenderer.getCamera().getPos();

        MatrixStack matrices;
        try {
            // 1.21.11 yarn-mapped: matrices()
            matrices = context.matrices();
        } catch (Throwable e) {
            return;
        }
        if (matrices == null) return;

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);

        try {
            Tessellator tessellator = Tessellator.getInstance();

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableDepthTest();
            RenderSystem.lineWidth(2.0f);

            try {
                RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            } catch (Throwable ignored) {
            }

            // === OUTLINES ===
            BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

            if (ModConfig.susChunkEnabled && ModConfig.showOutline) {
                for (SusChunkModule.ChunkData data : SusChunkModule.getSusChunks().values()) {
                    int color = data.percent >= 50 ? ModConfig.highPercentColor : ModConfig.outlineColor;
                    drawChunkOutline(buffer, matrices, data.pos, color, client);
                }
            }

            if (ModConfig.playerDebugEnabled) {
                for (Long key : PlayerDebugModule.getPlayerChunks()) {
                    drawChunkOutline(buffer, matrices, new ChunkPos(key), ModConfig.playerChunkColor, client);
                }
            }

            if (ModConfig.storageEspEnabled) {
                for (BlockPos pos : StorageEspModule.storagePositions) {
                    drawBoxOutline(buffer, matrices, pos, ModConfig.storageEspColor);
                }
            }

            BufferRenderer.drawWithGlobalProgram(buffer.end());

            // === FILLS ===
            if (ModConfig.showFill) {
                buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                if (ModConfig.susChunkEnabled) {
                    for (SusChunkModule.ChunkData data : SusChunkModule.getSusChunks().values()) {
                        int color = data.percent >= 50 ? ModConfig.highPercentColor : ModConfig.fillColor;
                        drawChunkFill(buffer, matrices, data.pos, color, client);
                    }
                }
                if (ModConfig.playerDebugEnabled) {
                    for (Long key : PlayerDebugModule.getPlayerChunks()) {
                        drawChunkFill(buffer, matrices, new ChunkPos(key), ModConfig.playerFillColor, client);
                    }
                }
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            }

            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
        } finally {
            matrices.pop();
        }
    }

    private static void drawChunkOutline(BufferBuilder buffer, MatrixStack matrices, ChunkPos pos, int color, MinecraftClient client) {
        float a = ((color >> 24) & 0xFF) / 255f;
        if (a <= 0) a = 1f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        int x1 = pos.getStartX();
        int z1 = pos.getStartZ();
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        int y1 = client.world.getBottomY();
        int y2 = Math.max(y1 + 1, ModConfig.scanYLevel + 1);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);

        line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);

        line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void drawChunkFill(BufferBuilder buffer, MatrixStack matrices, ChunkPos pos, int color, MinecraftClient client) {
        float a = ModConfig.fillOpacity;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        int x1 = pos.getStartX();
        int z1 = pos.getStartZ();
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        int y1 = client.world.getBottomY();
        int y2 = Math.max(y1 + 1, ModConfig.scanYLevel + 1);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        quad(buffer, matrix, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1, r, g, b, a);
        quad(buffer, matrix, x1, y1, z2, x1, y2, z2, x2, y2, z2, x2, y1, z2, r, g, b, a);
        quad(buffer, matrix, x1, y1, z1, x1, y2, z1, x1, y2, z2, x1, y1, z2, r, g, b, a);
        quad(buffer, matrix, x2, y1, z1, x2, y1, z2, x2, y2, z2, x2, y2, z1, r, g, b, a);
    }

    private static void drawBoxOutline(BufferBuilder buffer, MatrixStack matrices, BlockPos pos, int color) {
        float a = ((color >> 24) & 0xFF) / 255f;
        if (a <= 0) a = 1f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        float x1 = pos.getX(), y1 = pos.getY(), z1 = pos.getZ();
        float x2 = x1 + 1, y2 = y1 + 1, z2 = z1 + 1;

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
        line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
        line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void line(BufferBuilder buffer, Matrix4f matrix,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float r, float g, float b, float a) {
        buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a);
    }

    private static void quad(BufferBuilder buffer, Matrix4f matrix,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             float x4, float y4, float z4,
                             float r, float g, float b, float a) {
        buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a);
        buffer.vertex(matrix, x3, y3, z3).color(r, g, b, a);
        buffer.vertex(matrix, x4, y4, z4).color(r, g, b, a);
    }
}
